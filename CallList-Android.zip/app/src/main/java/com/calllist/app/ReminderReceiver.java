package com.calllist.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** يعرض إشعار تذكير بالاتصال بالعملاء المؤجَّلين. */
public class ReminderReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context c, Intent i) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("rem", "تذكيرات الاتصال", NotificationManager.IMPORTANCE_HIGH));
        PendingIntent open = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(c, "rem")
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(i.getStringExtra("t"))
                .setContentText(i.getStringExtra("x"))
                .setContentIntent(open)
                .setAutoCancel(true)
                .build();
        nm.notify(i.getIntExtra("id", 0), n);
    }
}
