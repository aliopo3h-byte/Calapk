package com.calllist.app;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.AudioManager;
import android.provider.CallLog;
import android.telephony.TelephonyManager;

/** يلتقط بدء المكالمة ونهايتها، ويقرأ مدتها من سجل الاتصالات ليعرف هل ردّ العميل. */
public class PhoneStateReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context ctx, Intent intent) {
        String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
        if (state == null) return;
        SharedPreferences p = ctx.getSharedPreferences("cl", Context.MODE_PRIVATE);
        final String num = p.getString("pend", "");
        if (num.isEmpty()) return;

        if (TelephonyManager.EXTRA_STATE_OFFHOOK.equals(state)) {
            p.edit().putBoolean("off", true).apply();
            if (p.getBoolean("spk", false)) {
                try {
                    ((AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE)).setSpeakerphoneOn(true);
                } catch (Exception e) {
                    // not supported on this device
                }
            }
        } else if (TelephonyManager.EXTRA_STATE_IDLE.equals(state) && p.getBoolean("off", false)) {
            OverlayHelper.hide();
            final long since = p.getLong("dialAt", 0);
            p.edit().remove("pend").putBoolean("off", false).apply();
            try {
                ((AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE)).setSpeakerphoneOn(false);
            } catch (Exception e) {
                // ignore
            }
            final PendingResult pr = goAsync();
            final Context app = ctx.getApplicationContext();
            new Thread(() -> {
                try {
                    finishCall(app, num, since);
                } catch (Exception e) {
                    // ignore
                } finally {
                    pr.finish();
                }
            }).start();
        }
    }

    private static void finishCall(Context c, String num, long since) throws Exception {
        Thread.sleep(1800); // سجل الاتصالات يتأخر قليلاً في الكتابة
        long dur = -1;
        for (int k = 0; k < 3 && dur < 0; k++) {
            dur = queryDuration(c, num, since);
            if (dur < 0) Thread.sleep(1200);
        }
        String json = "{\"number\":\"" + num.replaceAll("[^0-9+]", "") + "\",\"duration\":"
                + Math.max(dur, 0) + ",\"ok\":" + (dur >= 0) + "}";
        c.getSharedPreferences("cl", Context.MODE_PRIVATE).edit().putString("ended", json).apply();
    }

    private static long queryDuration(Context c, String num, long since) {
        if (c.checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) return -1;
        String tail = tail(num);
        try (Cursor cur = c.getContentResolver().query(
                CallLog.Calls.CONTENT_URI,
                new String[]{CallLog.Calls.NUMBER, CallLog.Calls.DURATION},
                CallLog.Calls.DATE + " >= ? AND " + CallLog.Calls.TYPE + " = ?",
                new String[]{String.valueOf(since - 5000), String.valueOf(CallLog.Calls.OUTGOING_TYPE)},
                CallLog.Calls.DATE + " DESC")) {
            if (cur == null) return -1;
            while (cur.moveToNext()) {
                if (tail(cur.getString(0)).equals(tail)) return cur.getLong(1);
            }
        } catch (Exception e) {
            // no access to the call log
        }
        return -1;
    }

    private static String tail(String s) {
        if (s == null) return "";
        String d = s.replaceAll("[^0-9]", "");
        return d.length() > 7 ? d.substring(d.length() - 7) : d;
    }
}
