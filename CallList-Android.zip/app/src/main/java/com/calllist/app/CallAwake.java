package com.calllist.app;

import android.content.Context;
import android.os.PowerManager;

/** يُبقي الشاشة مضاءة طوال المكالمة التي بدأها التطبيق (يمكن إيقافه من الإعدادات). */
final class CallAwake {
    private static PowerManager.WakeLock lock;
    private static volatile boolean active;

    private CallAwake() { }

    static boolean enabled(Context c) {
        return c.getApplicationContext().getSharedPreferences("cl", Context.MODE_PRIVATE).getBoolean("awake", true);
    }

    static boolean active() {
        return active;
    }

    /** بدأت المكالمة: النافذة العائمة تمنع انطفاء الشاشة، وقفل الطاقة احتياطٌ إن كانت النافذة غير مفعّلة. */
    @SuppressWarnings("deprecation")
    static synchronized void on(Context c) {
        Context app = c.getApplicationContext();
        if (!enabled(app)) return;
        active = true;
        OverlayHelper.keepAwake(true);
        try {
            PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
            if (pm == null) return;
            if (lock == null) {
                lock = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ON_AFTER_RELEASE, "calllist:call");
                lock.setReferenceCounted(false);
            }
            lock.acquire(30 * 60 * 1000L); // حدّ أقصى احتياطي حتى لا يبقى القفل إن فاتنا إشعار نهاية المكالمة
        } catch (Exception e) {
            // the overlay flag still keeps the screen on
        }
    }

    /** انتهت المكالمة (أو لم تبدأ): نعيد للشاشة سلوكها العادي. */
    static synchronized void off() {
        active = false;
        OverlayHelper.keepAwake(false);
        try {
            if (lock != null && lock.isHeld()) lock.release();
        } catch (Exception e) {
            // already released
        }
    }
}
