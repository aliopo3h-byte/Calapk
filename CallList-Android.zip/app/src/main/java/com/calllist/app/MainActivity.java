package com.calllist.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.telephony.SmsManager;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 11, REQ_PERM = 12, REQ_SMS = 13;
    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";

    private WebView web;
    private ValueCallback<Uri[]> chooser;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setTextZoom(100);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("tel".equals(u.getScheme())) {
                    placeCall(u.getSchemeSpecificPart());
                    return true;
                }
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) {
                    // no app can open this link
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "اختر الملف"), REQ_FILE);
                } catch (Exception e) {
                    chooser = null;
                    cb.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl(HOME);
        askPermissions();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            chooser = null;
        }
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }

    private void askPermissions() {
        List<String> need = new ArrayList<>();
        List<String> all = new ArrayList<>();
        all.add(Manifest.permission.CALL_PHONE);
        all.add(Manifest.permission.READ_PHONE_STATE);
        all.add(Manifest.permission.READ_CALL_LOG);
        if (Build.VERSION.SDK_INT >= 33) all.add(Manifest.permission.POST_NOTIFICATIONS);
        for (String p : all) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        }
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), REQ_PERM);
    }

    private void placeCall(String num) {
        if (num == null || num.isEmpty()) return;
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            getSharedPreferences("cl", MODE_PRIVATE).edit()
                    .putString("pend", num)
                    .putLong("dialAt", System.currentTimeMillis())
                    .putBoolean("off", false)
                    .remove("ended")
                    .apply();
            try {
                startActivity(new Intent(Intent.ACTION_CALL, Uri.fromParts("tel", num, null)));
            } catch (Exception e) {
                Toast.makeText(this, "تعذّر إجراء الاتصال", Toast.LENGTH_SHORT).show();
            }
        } else {
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, REQ_PERM);
            Toast.makeText(this, "اسمح بصلاحية الاتصال ثم اضغط مرة أخرى", Toast.LENGTH_LONG).show();
        }
    }

    /** الجسر بين الصفحة وهذا التطبيق (يُستدعى من JavaScript باسم Android) */
    private class Bridge {
        @JavascriptInterface
        public void call(final String num) {
            runOnUiThread(() -> placeCall(num));
        }

        @JavascriptInterface
        public String pollCallEnded() {
            SharedPreferences p = getSharedPreferences("cl", MODE_PRIVATE);
            String s = p.getString("ended", "");
            if (!s.isEmpty()) p.edit().remove("ended").apply();
            return s;
        }

        @JavascriptInterface
        public boolean saveFile(String b64, String name, String mime, boolean share) {
            try {
                byte[] data = Base64.decode(b64, Base64.DEFAULT);
                if (share) {
                    File dir = new File(getCacheDir(), "share");
                    dir.mkdirs();
                    File f = new File(dir, name);
                    try (OutputStream o = new FileOutputStream(f)) {
                        o.write(data);
                    }
                    final Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
                    final String m = mime;
                    runOnUiThread(() -> {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType(m);
                        i.putExtra(Intent.EXTRA_STREAM, uri);
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(i, null));
                    });
                    return true;
                }
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/CallList");
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) return false;
                try (OutputStream o = getContentResolver().openOutputStream(u)) {
                    o.write(data);
                }
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void shareText(final String t) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, t);
                startActivity(Intent.createChooser(i, null));
            });
        }

        @JavascriptInterface
        public void scheduleReminder(int id, long when, String title, String text) {
            Intent i = new Intent(MainActivity.this, ReminderReceiver.class);
            i.putExtra("id", id);
            i.putExtra("t", title);
            i.putExtra("x", text);
            PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, id, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        }

        @JavascriptInterface
        public void cancelReminder(int id) {
            Intent i = new Intent(MainActivity.this, ReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, id, i,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) {
                ((AlarmManager) getSystemService(ALARM_SERVICE)).cancel(pi);
            }
        }

        @JavascriptInterface
        public void setSpeaker(boolean on) {
            getSharedPreferences("cl", MODE_PRIVATE).edit().putBoolean("spk", on).apply();
        }

        @JavascriptInterface
        public void requestSms() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.SEND_SMS}, REQ_SMS);
                }
            });
        }

        @JavascriptInterface
        public boolean sendSms(String num, String text) {
            if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return false;
            try {
                SmsManager sm = getSystemService(SmsManager.class);
                sm.sendMultipartTextMessage(num, null, sm.divideMessage(text), null, null);
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }
}
