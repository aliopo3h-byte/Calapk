package com.calllist.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.database.Cursor;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.telecom.TelecomManager;
import android.telephony.SmsManager;
import android.util.Base64;
import android.view.View;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 11, REQ_PERM = 12, REQ_SMS = 13, REQ_MIC = 14;
    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    public static final String ACTION_CALL_NEXT = "com.calllist.app.CALL_NEXT";

    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private boolean pageReady = false;
    private final ArrayList<String> pendingJs = new ArrayList<>();
    private boolean ttsReady = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                pageReady = true;
                for (String c : pendingJs) v.evaluateJavascript(c, null);
                pendingJs.clear();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("tel".equals(u.getScheme())) {
                    placeCall(u.getSchemeSpecificPart());
                    return true;
                }
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) {
                    // no app can open this link
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "اختر الملف"), REQ_FILE);
                } catch (Exception e) {
                    chooser = null;
                    cb.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });

        tts = new TextToSpeech(this, status -> ttsReady = (status == TextToSpeech.SUCCESS));
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl(HOME);
        handleIntent(getIntent());
        askPermissions();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            chooser = null;
        }
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (recognizer != null) recognizer.destroy();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    private void runJs(final String code) {
        runOnUiThread(() -> {
            if (pageReady && web != null) web.evaluateJavascript(code, null);
            else pendingJs.add(code);
        });
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handleIntent(i);
    }

    @Override
    protected void onResume() {
        super.onResume();
        OverlayHelper.hide();
    }

    private void handleIntent(Intent i) {
        if (i == null) return;
        String act = i.getAction();
        if (ACTION_CALL_NEXT.equals(act)) {
            runJs("window.onWidgetCallNext && onWidgetCallNext()");
            return;
        }
        Uri u = null;
        if (Intent.ACTION_VIEW.equals(act)) {
            u = i.getData();
        } else if (Intent.ACTION_SEND.equals(act)) {
            u = Build.VERSION.SDK_INT >= 33 ? i.getParcelableExtra(Intent.EXTRA_STREAM, Uri.class) : i.getParcelableExtra(Intent.EXTRA_STREAM);
        }
        if (u != null) loadSharedFile(u);
    }

    private String displayName(Uri u) {
        try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                String n = c.getString(0);
                if (n != null && !n.isEmpty()) return n;
            }
        } catch (Exception e) {
            // fall through
        }
        String seg = u.getLastPathSegment();
        return seg == null ? "list.xlsx" : seg;
    }

    private void loadSharedFile(final Uri u) {
        new Thread(() -> {
            try (InputStream in = getContentResolver().openInputStream(u)) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n, total = 0;
                while (in != null && (n = in.read(buf)) > 0) {
                    bo.write(buf, 0, n);
                    total += n;
                    if (total > 15 * 1024 * 1024) throw new Exception("too big");
                }
                String name = displayName(u);
                String b64 = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
                runJs("window.onNativeFile && onNativeFile(" + JSONObject.quote(name) + ",\"" + b64 + "\")");
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "تعذّر قراءة الملف", Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void js(final String code) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_MIC) {
            boolean ok = res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED;
            js("window.onVoicePerm && onVoicePerm(" + ok + ")");
        }
    }

    private void askPermissions() {
        List<String> need = new ArrayList<>();
        List<String> all = new ArrayList<>();
        all.add(Manifest.permission.CALL_PHONE);
        all.add(Manifest.permission.READ_PHONE_STATE);
        all.add(Manifest.permission.READ_CALL_LOG);
        if (Build.VERSION.SDK_INT >= 33) all.add(Manifest.permission.POST_NOTIFICATIONS);
        for (String p : all) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        }
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), REQ_PERM);
    }

    private void placeCall(String num) {
        if (num == null || num.isEmpty()) return;
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            getSharedPreferences("cl", MODE_PRIVATE).edit()
                    .putString("pend", num)
                    .putLong("dialAt", System.currentTimeMillis())
                    .putBoolean("off", false)
                    .remove("ended")
                    .remove("res")
                    .remove("pnote")
                    .apply();
            Uri uri = Uri.fromParts("tel", num, null);
            boolean spk = getSharedPreferences("cl", MODE_PRIVATE).getBoolean("spk", false);
            try {
                // الطريقة الرسمية لبدء المكالمة بمكبّر الصوت عبر نظام الاتصالات
                Bundle ex = new Bundle();
                ex.putBoolean(TelecomManager.EXTRA_START_CALL_WITH_SPEAKERPHONE, spk);
                ((TelecomManager) getSystemService(TELECOM_SERVICE)).placeCall(uri, ex);
            } catch (Exception first) {
                try {
                    Intent ci = new Intent(Intent.ACTION_CALL, uri);
                    ci.putExtra(TelecomManager.EXTRA_START_CALL_WITH_SPEAKERPHONE, spk);
                    startActivity(ci);
                } catch (Exception e) {
                    Toast.makeText(this, "تعذّر إجراء الاتصال", Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, REQ_PERM);
            Toast.makeText(this, "اسمح بصلاحية الاتصال ثم اضغط مرة أخرى", Toast.LENGTH_LONG).show();
        }
    }

    /** الجسر بين الصفحة وهذا التطبيق (يُستدعى من JavaScript باسم Android) */
    private class Bridge {
        @JavascriptInterface
        public void call(final String num) {
            runOnUiThread(() -> placeCall(num));
        }

        @JavascriptInterface
        public String pollCallEnded() {
            SharedPreferences p = getSharedPreferences("cl", MODE_PRIVATE);
            String s = p.getString("ended", "");
            if (!s.isEmpty()) p.edit().remove("ended").apply();
            return s;
        }

        @JavascriptInterface
        public boolean saveFile(String b64, String name, String mime, boolean share) {
            try {
                byte[] data = Base64.decode(b64, Base64.DEFAULT);
                if (share) {
                    File dir = new File(getCacheDir(), "share");
                    dir.mkdirs();
                    File f = new File(dir, name);
                    try (OutputStream o = new FileOutputStream(f)) {
                        o.write(data);
                    }
                    final Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
                    final String m = mime;
                    runOnUiThread(() -> {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType(m);
                        i.putExtra(Intent.EXTRA_STREAM, uri);
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(i, null));
                    });
                    return true;
                }
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/CallList");
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) return false;
                try (OutputStream o = getContentResolver().openOutputStream(u)) {
                    o.write(data);
                }
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void shareText(final String t) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, t);
                startActivity(Intent.createChooser(i, null));
            });
        }

        @JavascriptInterface
        public void scheduleReminder(int id, long when, String title, String text) {
            Intent i = new Intent(MainActivity.this, ReminderReceiver.class);
            i.putExtra("id", id);
            i.putExtra("t", title);
            i.putExtra("x", text);
            PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, id, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        }

        @JavascriptInterface
        public void cancelReminder(int id) {
            Intent i = new Intent(MainActivity.this, ReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, id, i,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) {
                ((AlarmManager) getSystemService(ALARM_SERVICE)).cancel(pi);
            }
        }

        @JavascriptInterface
        public boolean isDark() {
            return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                    == Configuration.UI_MODE_NIGHT_YES;
        }

        @JavascriptInterface
        public boolean inCall() {
            return getSharedPreferences("cl", MODE_PRIVATE).getBoolean("off", false);
        }

        @JavascriptInterface
        public void setBars(final boolean dark) {
            runOnUiThread(() -> {
                getWindow().setStatusBarColor(dark ? 0xFF13294F : 0xFF1E4E9C);
                getWindow().setNavigationBarColor(dark ? 0xFF172233 : 0xFFFFFFFF);
                if (Build.VERSION.SDK_INT >= 30) {
                    WindowInsetsController c = getWindow().getInsetsController();
                    if (c != null) {
                        c.setSystemBarsAppearance(dark ? 0 : WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
                    }
                } else {
                    View d = getWindow().getDecorView();
                    int f = d.getSystemUiVisibility();
                    d.setSystemUiVisibility(dark ? (f & ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
                            : (f | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR));
                }
            });
        }

        @JavascriptInterface
        public void speak(final String text, final String lang, final float rate) {
            runOnUiThread(() -> {
                if (!ttsReady || tts == null) return;
                int r = tts.setLanguage(new Locale(lang));
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.getDefault());
                tts.setSpeechRate(rate);
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "name");
            });
        }

        @JavascriptInterface
        public void stopSpeak() {
            runOnUiThread(() -> { if (tts != null) tts.stop(); });
        }

        @JavascriptInterface
        public boolean hasOverlay() {
            return Settings.canDrawOverlays(MainActivity.this);
        }

        @JavascriptInterface
        public void requestOverlay() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()))));
        }

        @JavascriptInterface
        public void showOverlay(String name, String note) {
            OverlayHelper.show(MainActivity.this, name, note, -1);
        }

        @JavascriptInterface
        public void showOverlay(String name, String note, int idx) {
            OverlayHelper.show(MainActivity.this, name, note, idx);
        }

        @JavascriptInterface
        public String pollResult() {
            SharedPreferences p = getSharedPreferences("cl", MODE_PRIVATE);
            String s = p.getString("res", "");
            if (!s.isEmpty()) p.edit().remove("res").apply();
            return s;
        }

        /** ما اختاره المستخدم في النافذة العائمة من «سيدفع بعد N أيام» بالصيغة «N:رقم_المشترك» (تُقرأ مرة واحدة). */
        @JavascriptInterface
        public String pollPay() {
            SharedPreferences p = getSharedPreferences("cl", MODE_PRIVATE);
            String s = p.getString("pnote", "");
            if (!s.isEmpty()) p.edit().remove("pnote").apply();
            return s;
        }

        @JavascriptInterface
        public void setReturn(boolean on) {
            getSharedPreferences("cl", MODE_PRIVATE).edit().putBoolean("ret", on).apply();
        }

        @JavascriptInterface
        public void hideOverlay() {
            OverlayHelper.hide();
        }

        @JavascriptInterface
        public void updateWidget(int called, int total, String next) {
            getSharedPreferences("cl", MODE_PRIVATE).edit()
                    .putInt("w_called", called).putInt("w_total", total).putString("w_next", next == null ? "" : next).apply();
            CallWidget.refresh(MainActivity.this);
        }

        @JavascriptInterface
        public void requestMic() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                }
            });
        }

        @JavascriptInterface
        public void listen(final String lang) {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                    return;
                }
                if (!SpeechRecognizer.isRecognitionAvailable(MainActivity.this)) {
                    js("window.onVoiceError && onVoiceError('unavailable')");
                    return;
                }
                if (recognizer != null) recognizer.destroy();
                recognizer = SpeechRecognizer.createSpeechRecognizer(MainActivity.this);
                recognizer.setRecognitionListener(new RecognitionListener() {
                    public void onReadyForSpeech(Bundle p) { }
                    public void onBeginningOfSpeech() { }
                    public void onRmsChanged(float v) { }
                    public void onBufferReceived(byte[] b) { }
                    public void onEndOfSpeech() { }
                    public void onPartialResults(Bundle p) { }
                    public void onEvent(int t, Bundle p) { }
                    public void onError(int e) { js("window.onVoiceError && onVoiceError(" + e + ")"); }
                    public void onResults(Bundle r) {
                        ArrayList<String> l = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if (l == null) l = new ArrayList<>();
                        js("window.onVoice && onVoice(" + new JSONArray(l).toString() + ")");
                    }
                });
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
                i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
                i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
                recognizer.startListening(i);
            });
        }

        @JavascriptInterface
        public void stopListen() {
            runOnUiThread(() -> { if (recognizer != null) recognizer.cancel(); });
        }

        @JavascriptInterface
        public void setKeepAwake(boolean on) {
            getSharedPreferences("cl", MODE_PRIVATE).edit().putBoolean("awake", on).apply();
        }

        @JavascriptInterface
        public void setSpeaker(boolean on) {
            getSharedPreferences("cl", MODE_PRIVATE).edit().putBoolean("spk", on).apply();
        }

        @JavascriptInterface
        public void requestSms() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.SEND_SMS}, REQ_SMS);
                }
            });
        }

        @JavascriptInterface
        public boolean sendSms(String num, String text) {
            if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return false;
            try {
                SmsManager sm = getSystemService(SmsManager.class);
                sm.sendMultipartTextMessage(num, null, sm.divideMessage(text), null, null);
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }
}
