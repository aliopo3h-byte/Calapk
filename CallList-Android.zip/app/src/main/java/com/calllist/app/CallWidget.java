package com.calllist.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

/** أداة الشاشة الرئيسية: تعرض التقدّم وزر «اتصل بالتالي». */
public class CallWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) m.updateAppWidget(id, build(c));
    }

    static RemoteViews build(Context c) {
        SharedPreferences p = c.getSharedPreferences("cl", Context.MODE_PRIVATE);
        int called = p.getInt("w_called", 0), total = p.getInt("w_total", 0);
        String next = p.getString("w_next", "");

        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
        v.setTextViewText(R.id.w_count, total == 0 ? "لا توجد قائمة" : called + " / " + total);
        v.setProgressBar(R.id.w_bar, 100, total == 0 ? 0 : called * 100 / total, false);
        v.setTextViewText(R.id.w_next, total == 0 ? "افتح التطبيق وارفع ملفاً"
                : (called >= total ? "انتهت القائمة" : "التالي: " + next));

        Intent call = new Intent(c, MainActivity.class);
        call.setAction(MainActivity.ACTION_CALL_NEXT);
        call.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        v.setOnClickPendingIntent(R.id.w_btn, PendingIntent.getActivity(c, 1, call,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));

        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        v.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(c, 2, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        return v;
    }

    static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, CallWidget.class));
        for (int id : ids) m.updateAppWidget(id, build(c));
    }
}
