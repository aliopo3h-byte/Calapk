package com.calllist.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

/** نافذة عائمة فوق شاشة الاتصال: اسم المشترك وملاحظته وأزرار النتيجة. */
final class OverlayHelper {
    private static View view;
    private static WindowManager wm;
    private static TextView statusLine;
    private static WindowManager.LayoutParams winLp;
    private static final ArrayList<TextView> BTNS = new ArrayList<>();
    private static final ArrayList<String> KEYS = new ArrayList<>();
    private static final ArrayList<TextView> PAY_BTNS = new ArrayList<>();
    private static final ArrayList<Integer> PAY_NUM = new ArrayList<>();
    private static final int[] PAY_DAYS = {2, 4, 7};
    private static final String PAY_HINT = "\uD83D\uDCB5 سيدفع بعد (يوم)";
    private static TextView payCap;
    private static int payPicked;
    private static final Handler H = new Handler(Looper.getMainLooper());

    private OverlayHelper() { }

    static void show(final Context ctx, final String name, final String note, final int idx) {
        H.post(() -> {
            final Context c = ctx.getApplicationContext();
            if (!Settings.canDrawOverlays(c)) return;
            hideNow();
            wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
            final float d = c.getResources().getDisplayMetrics().density;

            LinearLayout box = new LinearLayout(c);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            int p = (int) (14 * d);
            box.setPadding(p, p, p, p);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xF2142033);
            bg.setCornerRadius(22 * d);
            bg.setStroke((int) (2 * d), 0xFF4DA3FF);
            box.setBackground(bg);

            box.addView(label(c, "المشترك الحالي", 12, 0xFF9CD0FF, false, 0));
            box.addView(label(c, name == null ? "" : name, 22, 0xFFFFFFFF, true, 0));
            if (note != null && !note.trim().isEmpty()) {
                TextView nt = label(c, note, 15, 0xFFFFE9A8, false, (int) (6 * d));
                nt.setMaxLines(10);
                box.addView(nt);
            }

            BTNS.clear();
            KEYS.clear();
            PAY_BTNS.clear();
            PAY_NUM.clear();
            payCap = null;
            payPicked = 0;
            statusLine = null;
            if (idx >= 0) {
                String[][] opts = {
                        {"yes", "وافق", "#19B57A", "#FFFFFF"},
                        {"no", "رفض", "#EF6A63", "#FFFFFF"},
                        {"na", "لم يرد", "#F6C451", "#2B1E00"},
                        {"cb", "لاحقاً", "#2F6FD6", "#FFFFFF"}};
                LinearLayout row = new LinearLayout(c);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                row.setPadding(0, (int) (10 * d), 0, 0);
                for (final String[] o : opts) {
                    TextView b = new TextView(c);
                    b.setText(o[1]);
                    b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
                    b.setTypeface(Typeface.DEFAULT_BOLD);
                    b.setTextColor(android.graphics.Color.parseColor(o[3]));
                    b.setGravity(Gravity.CENTER);
                    GradientDrawable bb = new GradientDrawable();
                    bb.setColor(android.graphics.Color.parseColor(o[2]));
                    bb.setCornerRadius(14 * d);
                    b.setBackground(bb);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, (int) (46 * d), 1f);
                    lp.setMargins((int) (3 * d), 0, (int) (3 * d), 0);
                    b.setLayoutParams(lp);
                    final String key = o[0], lab = o[1];
                    b.setOnClickListener(v -> choose(c, key, lab, idx));
                    BTNS.add(b);
                    KEYS.add(key);
                    row.addView(b);
                }
                box.addView(row);

                // «سيدفع بعد»: ثلاثة أزرار 2 / 4 / 7 أيام تُسجَّل ملاحظةً للمشترك (الضغط مرة ثانية يلغيها)
                LinearLayout prow = new LinearLayout(c);
                prow.setOrientation(LinearLayout.HORIZONTAL);
                prow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                prow.setGravity(Gravity.CENTER_VERTICAL);
                prow.setPadding(0, (int) (10 * d), 0, 0);
                payCap = label(c, PAY_HINT, 13, 0xFFCFC2FF, true, 0);
                payCap.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.5f));
                prow.addView(payCap);
                for (final int n : PAY_DAYS) {
                    TextView pb = new TextView(c);
                    pb.setText(String.valueOf(n));
                    pb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
                    pb.setTypeface(Typeface.DEFAULT_BOLD);
                    pb.setTextColor(0xFFFFFFFF);
                    pb.setGravity(Gravity.CENTER);
                    GradientDrawable pbg = new GradientDrawable();
                    pbg.setColor(0xFF7C5CFF);
                    pbg.setCornerRadius(14 * d);
                    pb.setBackground(pbg);
                    LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(0, (int) (44 * d), 1f);
                    plp.setMargins((int) (3 * d), 0, (int) (3 * d), 0);
                    pb.setLayoutParams(plp);
                    pb.setOnClickListener(v -> payChoose(c, n, idx));
                    PAY_BTNS.add(pb);
                    PAY_NUM.add(n);
                    prow.addView(pb);
                }
                box.addView(prow);

                statusLine = label(c, "اضغط النتيجة وأنت تتحدث، وتُسجَّل عند انتهاء المكالمة", 12, 0xFF9CD0FF, false, (int) (8 * d));
                box.addView(statusLine);
            }

            TextView close = label(c, "\u2715 إغلاق", 13, 0xFFFFB3B3, false, (int) (8 * d));
            close.setOnClickListener(v -> hideNow());
            box.addView(close);

            int w = (int) (c.getResources().getDisplayMetrics().widthPixels * 0.94f);
            final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    w, WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            lp.y = (int) (70 * d);
            if (CallAwake.active()) lp.flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON; // المكالمة بدأت قبل ظهور النافذة

            final int[] start = new int[1];
            final float[] down = new float[1];
            box.setOnTouchListener((v, ev) -> {
                switch (ev.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        start[0] = lp.y;
                        down[0] = ev.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.y = start[0] + (int) (ev.getRawY() - down[0]);
                        try { wm.updateViewLayout(v, lp); } catch (Exception e) { /* ignore */ }
                        return true;
                    default:
                        return false;
                }
            });
            try {
                wm.addView(box, lp);
                view = box;
                winLp = lp;
            } catch (Exception e) {
                view = null;
            }
        });
    }

    /** حفظ اختيارك لتطبيقه عند عودة التطبيق (الصفحة تقرأه بعد انتهاء المكالمة). */
    private static void choose(Context c, String key, String label, int idx) {
        SharedPreferences p = c.getSharedPreferences("cl", Context.MODE_PRIVATE);
        p.edit().putString("res", key + ":" + idx).apply();
        for (int i = 0; i < BTNS.size(); i++) {
            BTNS.get(i).setAlpha(KEYS.get(i).equals(key) ? 1f : 0.35f);
        }
        if (statusLine != null) statusLine.setText("\u2713 سُجّل: " + label + " (يمكنك تغيير اختيارك)");
    }

    /** ملاحظة «سيدفع بعد N أيام»: تُحفظ بالصيغة «N:رقم_المشترك» وتقرؤها الصفحة عند العودة. الضغط على نفس الرقم يلغيها (N = 0). */
    private static void payChoose(Context c, int n, int idx) {
        payPicked = payPicked == n ? 0 : n;
        SharedPreferences p = c.getSharedPreferences("cl", Context.MODE_PRIVATE);
        p.edit().putString("pnote", payPicked + ":" + idx).apply();
        for (int i = 0; i < PAY_BTNS.size(); i++) {
            PAY_BTNS.get(i).setAlpha(payPicked == 0 || PAY_NUM.get(i) == payPicked ? 1f : 0.35f);
        }
        if (payCap != null) {
            if (payPicked == 0) {
                payCap.setText(PAY_HINT);
                payCap.setTextColor(0xFFCFC2FF);
            } else {
                payCap.setText("\u2713 سيدفع بعد " + (payPicked == 2 ? "يومين" : payPicked + " أيام"));
                payCap.setTextColor(0xFF7CF0B5);
            }
        }
    }

    /** أثناء المكالمة: النافذة المرئية بعلَم «أبقِ الشاشة مضاءة» تمنع انطفاء الشاشة حتى فوق شاشة الاتصال. */
    static void keepAwake(final boolean on) {
        H.post(() -> {
            if (view == null || wm == null || winLp == null) return;
            if (on) winLp.flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
            else winLp.flags &= ~WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
            try { wm.updateViewLayout(view, winLp); } catch (Exception e) { /* window already gone */ }
        });
    }

    static void hide() {
        H.post(OverlayHelper::hideNow);
    }

    private static void hideNow() {
        if (view != null && wm != null) {
            try { wm.removeView(view); } catch (Exception e) { /* already removed */ }
        }
        view = null;
        winLp = null;
        statusLine = null;
        payCap = null;
        BTNS.clear();
        KEYS.clear();
        PAY_BTNS.clear();
        PAY_NUM.clear();
    }

    private static TextView label(Context c, String text, int sp, int color, boolean bold, int topPad) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, topPad, 0, 0);
        t.setTextDirection(View.TEXT_DIRECTION_RTL);
        t.setGravity(Gravity.START);
        return t;
    }
}
